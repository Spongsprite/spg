import { useState } from 'react'
import { Search, Filter } from 'lucide-react'
import { Button } from '@/components/ui/button'

interface SearchBarProps {
  searchTerm: string
  onSearchChange: (term: string) => void
  onFilterToggle: () => void
}

export function SearchBar({ searchTerm, onSearchChange, onFilterToggle }: SearchBarProps) {
  const [suggestions] = useState([
    'CBD Oil', 'Premium Strain', 'Gummies', 'Relaxant', 'Anti-stress'
  ])
  const [showSuggestions, setShowSuggestions] = useState(false)

  return (
    <div className="relative flex gap-2 mb-6">
      <div className="relative flex-1">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
        <input
          type="text"
          placeholder="Rechercher des produits..."
          value={searchTerm}
          onChange={(e) => onSearchChange(e.target.value)}
          onFocus={() => setShowSuggestions(true)}
          onBlur={() => setTimeout(() => setShowSuggestions(false), 200)}
          className="w-full pl-10 pr-4 py-3 bg-gray-800 border border-gray-600 rounded-lg focus:border-green-400 focus:outline-none text-white"
        />
        
        {showSuggestions && searchTerm && (
          <div className="absolute top-full left-0 right-0 bg-gray-800 border border-gray-600 rounded-lg mt-1 z-10">
            {suggestions
              .filter(suggestion => suggestion.toLowerCase().includes(searchTerm.toLowerCase()))
              .map((suggestion, index) => (
                <button
                  key={index}
                  onClick={() => {
                    onSearchChange(suggestion)
                    setShowSuggestions(false)
                  }}
                  className="w-full text-left px-4 py-2 hover:bg-gray-700 text-white first:rounded-t-lg last:rounded-b-lg"
                >
                  {suggestion}
                </button>
              ))
            }
          </div>
        )}
      </div>
      
      <Button
        onClick={onFilterToggle}
        className="bg-gray-800 border border-gray-600 text-white hover:bg-gray-700 px-4"
      >
        <Filter className="w-4 h-4" />
      </Button>
    </div>
  )
}
