import { useState } from 'react'
import { Star, ShoppingCart, Eye } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Product, ProductVariant } from '../types'

interface ProductCardProps {
  product: Product
  onAddToCart: (product: Product, variant?: ProductVariant) => void
  onViewDetails: (product: Product) => void
}

export function ProductCard({ product, onAddToCart, onViewDetails }: ProductCardProps) {
  const [selectedVariant, setSelectedVariant] = useState<ProductVariant | undefined>(
    product.variants?.[0]
  )

  const currentPrice = selectedVariant?.price || product.price
  const currentStock = selectedVariant?.stock || product.stock

  return (
    <div className="bg-gray-900/50 rounded-lg p-4 hover:bg-gray-900/70 transition-all duration-300">
      <div className="relative mb-4">
        <img
          src={product.image || "/placeholder.svg"}
          alt={product.name}
          className="w-full h-48 object-cover rounded-lg"
        />
        {product.isNew && (
          <span className="absolute top-2 left-2 bg-green-500 text-black px-2 py-1 rounded text-xs font-bold">
            NOUVEAU
          </span>
        )}
        {product.isPopular && (
          <span className="absolute top-2 right-2 bg-yellow-500 text-black px-2 py-1 rounded text-xs font-bold">
            POPULAIRE
          </span>
        )}
        {currentStock <= 5 && (
          <span className="absolute bottom-2 left-2 bg-red-500 text-white px-2 py-1 rounded text-xs font-bold">
            Stock faible: {currentStock}
          </span>
        )}
      </div>

      <div className="space-y-3">
        <div>
          <h3 className="text-lg font-semibold text-yellow-400 mb-1">{product.name}</h3>
          <p className="text-gray-300 text-sm line-clamp-2">{product.description}</p>
        </div>

        <div className="flex items-center gap-2">
          <div className="flex items-center">
            {[...Array(5)].map((_, i) => (
              <Star
                key={i}
                className={`w-4 h-4 ${
                  i < Math.floor(product.rating) ? 'text-yellow-400 fill-current' : 'text-gray-600'
                }`}
              />
            ))}
          </div>
          <span className="text-sm text-gray-400">({product.reviews})</span>
        </div>

        {product.effects && (
          <div className="flex flex-wrap gap-1">
            {product.effects.slice(0, 3).map((effect, index) => (
              <span
                key={index}
                className="bg-green-600/20 text-green-400 px-2 py-1 rounded text-xs"
              >
                {effect}
              </span>
            ))}
          </div>
        )}

        {product.variants && product.variants.length > 1 && (
          <div>
            <label className="block text-sm text-gray-400 mb-1">Format:</label>
            <select
              value={selectedVariant?.id || ''}
              onChange={(e) => {
                const variant = product.variants?.find(v => v.id === parseInt(e.target.value))
                setSelectedVariant(variant)
              }}
              className="w-full bg-gray-800 border border-gray-600 rounded px-2 py-1 text-sm text-white"
            >
              {product.variants.map((variant) => (
                <option key={variant.id} value={variant.id}>
                  {variant.name} - {variant.price.toFixed(2)} €
                </option>
              ))}
            </select>
          </div>
        )}

        <div className="flex items-center justify-between">
          <div className="text-2xl font-bold text-green-400">
            {currentPrice.toFixed(2)} €
          </div>
          <div className="flex gap-2">
            <Button
              size="sm"
              variant="outline"
              onClick={() => onViewDetails(product)}
              className="border-cyan-400 text-cyan-400 hover:bg-cyan-400 hover:text-black"
            >
              <Eye className="w-4 h-4" />
            </Button>
            <Button
              size="sm"
              onClick={() => onAddToCart(product, selectedVariant)}
              disabled={currentStock === 0}
              className="bg-green-600 hover:bg-green-700 text-white"
            >
              <ShoppingCart className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
