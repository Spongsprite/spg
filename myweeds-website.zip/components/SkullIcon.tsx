export function SkullIcon({ className = "w-24 h-24" }: { className?: string }) {
  return (
    <div className={`${className} flex items-center justify-center bg-gray-800 rounded-lg border-2 border-red-500`}>
      <div className="text-center">
        <div className="text-4xl mb-2">💀</div>
        <div className="text-xs text-red-400 font-bold">NO IMAGE</div>
      </div>
    </div>
  )
}
