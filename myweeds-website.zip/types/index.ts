export interface Product {
  id: number
  name: { fr: string; en: string; de: string }
  description: { fr: string; en: string; de: string }
  price: number
  image?: string
  category: string
  subcategory: string
  stock: number
  concentration?: string
  effects?: { fr: string[]; en: string[]; de: string[] }
  variants?: ProductVariant[]
  rating: number
  reviews: number
  isNew?: boolean
  isPopular?: boolean
}

export interface ProductVariant {
  id: number
  name: { fr: string; en: string; de: string }
  price: number
  stock: number
}

export interface CartItem extends Product {
  quantity: number
  selectedVariant?: ProductVariant
}

export interface User {
  id: number
  email: string
  firstName: string
  lastName: string
  pseudonym: string
  addresses: Address[]
  orders: Order[]
  loyaltyPoints: number
}

export interface Address {
  id: number
  firstName: string
  lastName: string
  street: string
  city: string
  postalCode: string
  country: string
  isDefault: boolean
}

export interface Order {
  id: number
  items: CartItem[]
  total: number
  status: 'pending' | 'confirmed' | 'shipped' | 'delivered' | 'cancelled'
  shippingAddress: Address
  paymentMethod: string
  trackingNumber?: string
  createdAt: Date
}

export type Language = 'fr' | 'en' | 'de'

export interface Translations {
  [key: string]: {
    fr: string
    en: string
    de: string
  }
}
