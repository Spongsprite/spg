import { useState, useEffect } from 'react'
import { User } from '../types'

export function useAuth() {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(false)

  const register = async (userData: {
    firstName: string
    lastName: string
    pseudonym: string
    email: string
    password: string
  }) => {
    setIsLoading(true)
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000))
      
      const newUser: User = {
        id: Date.now(),
        ...userData,
        addresses: [],
        orders: [],
        loyaltyPoints: 0
      }
      
      setUser(newUser)
      localStorage.setItem('myweeds-user', JSON.stringify(newUser))
      return { success: true }
    } catch (error) {
      return { success: false, error: 'Registration failed' }
    } finally {
      setIsLoading(false)
    }
  }

  const login = async (email: string, password: string) => {
    setIsLoading(true)
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000))
      
      // For demo, create a user
      const mockUser: User = {
        id: 1,
        email,
        firstName: 'John',
        lastName: 'Doe',
        pseudonym: 'johndoe',
        addresses: [],
        orders: [],
        loyaltyPoints: 150
      }
      
      setUser(mockUser)
      localStorage.setItem('myweeds-user', JSON.stringify(mockUser))
      return { success: true }
    } catch (error) {
      return { success: false, error: 'Login failed' }
    } finally {
      setIsLoading(false)
    }
  }

  const logout = () => {
    setUser(null)
    localStorage.removeItem('myweeds-user')
  }

  const sendPasswordReset = async (email: string) => {
    setIsLoading(true)
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000))
      return { success: true, message: 'Code de récupération envoyé par email' }
    } catch (error) {
      return { success: false, error: 'Failed to send reset code' }
    } finally {
      setIsLoading(false)
    }
  }

  const resetPassword = async (code: string, newPassword: string) => {
    setIsLoading(true)
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000))
      return { success: true, message: 'Mot de passe réinitialisé avec succès' }
    } catch (error) {
      return { success: false, error: 'Invalid code or reset failed' }
    } finally {
      setIsLoading(false)
    }
  }

  // Load user from localStorage on mount
  useEffect(() => {
    const savedUser = localStorage.getItem('myweeds-user')
    if (savedUser) {
      setUser(JSON.parse(savedUser))
    }
  }, [])

  return {
    user,
    isLoading,
    register,
    login,
    logout,
    sendPasswordReset,
    resetPassword
  }
}
