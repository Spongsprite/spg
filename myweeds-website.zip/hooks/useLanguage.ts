import { useState, useEffect } from 'react'
import { Language } from '../types'

export function useLanguage() {
  const [language, setLanguage] = useState<Language>('fr')

  useEffect(() => {
    const savedLanguage = localStorage.getItem('myweeds-language') as Language
    if (savedLanguage && ['fr', 'en', 'de'].includes(savedLanguage)) {
      setLanguage(savedLanguage)
    }
  }, [])

  const changeLanguage = (newLanguage: Language) => {
    setLanguage(newLanguage)
    localStorage.setItem('myweeds-language', newLanguage)
  }

  return { language, changeLanguage }
}
