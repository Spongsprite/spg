import { useState, useMemo } from 'react'
import { Product } from '../types'
import { Language } from '../types'

export function useSearch(products: Product[], language: Language = 'fr') {
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedCategory, setSelectedCategory] = useState('')
  const [selectedSubcategory, setSelectedSubcategory] = useState('')
  const [minPrice, setMinPrice] = useState<number>(0)
  const [maxPrice, setMaxPrice] = useState<number>(200)
  const [selectedEffects, setSelectedEffects] = useState<string[]>([])
  const [sortBy, setSortBy] = useState<'price-asc' | 'price-desc' | 'popularity' | 'newest' | 'rating'>('popularity')

  const filteredProducts = useMemo(() => {
    let filtered = products.filter(product => {
      const productName = product.name[language] || product.name.fr || ''
      const productDescription = product.description[language] || product.description.fr || ''
      
      const matchesSearch = productName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           productDescription.toLowerCase().includes(searchTerm.toLowerCase())
      
      const matchesCategory = !selectedCategory || product.category === selectedCategory
      const matchesSubcategory = !selectedSubcategory || product.subcategory === selectedSubcategory
      const matchesPrice = product.price >= minPrice && product.price <= maxPrice
      const matchesEffects = selectedEffects.length === 0 || 
                            (product.effects && selectedEffects.some(effect => 
                              product.effects?.[language]?.includes(effect) ||
                              product.effects?.fr?.includes(effect)
                            ))

      return matchesSearch && matchesCategory && matchesSubcategory && matchesPrice && matchesEffects
    })

    // Sort products
    switch (sortBy) {
      case 'price-asc':
        filtered.sort((a, b) => a.price - b.price)
        break
      case 'price-desc':
        filtered.sort((a, b) => b.price - a.price)
        break
      case 'rating':
        filtered.sort((a, b) => b.rating - a.rating)
        break
      case 'newest':
        filtered.sort((a, b) => (b.isNew ? 1 : 0) - (a.isNew ? 1 : 0))
        break
      case 'popularity':
      default:
        filtered.sort((a, b) => (b.isPopular ? 1 : 0) - (a.isPopular ? 1 : 0))
        break
    }

    return filtered
  }, [products, searchTerm, selectedCategory, selectedSubcategory, minPrice, maxPrice, selectedEffects, sortBy, language])

  return {
    searchTerm,
    setSearchTerm,
    selectedCategory,
    setSelectedCategory,
    selectedSubcategory,
    setSelectedSubcategory,
    minPrice,
    setMinPrice,
    maxPrice,
    setMaxPrice,
    selectedEffects,
    setSelectedEffects,
    sortBy,
    setSortBy,
    filteredProducts
  }
}
