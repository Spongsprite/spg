import { useState, useEffect } from 'react'
import { CartItem, Product, ProductVariant } from '../types'

export function useCart() {
  const [cart, setCart] = useState<CartItem[]>([])

  // Load cart from localStorage on mount
  useEffect(() => {
    const savedCart = localStorage.getItem('myweeds-cart')
    if (savedCart) {
      setCart(JSON.parse(savedCart))
    }
  }, [])

  // Save cart to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem('myweeds-cart', JSON.stringify(cart))
  }, [cart])

  const addToCart = (product: Product, variant?: ProductVariant) => {
    setCart(prev => {
      const existingItem = prev.find(item => 
        item.id === product.id && 
        item.selectedVariant?.id === variant?.id
      )
      
      if (existingItem) {
        return prev.map(item =>
          item.id === product.id && item.selectedVariant?.id === variant?.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        )
      }
      
      return [...prev, { 
        ...product, 
        quantity: 1, 
        selectedVariant: variant,
        price: variant?.price || product.price
      }]
    })
  }

  const updateQuantity = (id: number, variantId: number | undefined, change: number) => {
    setCart(prev => {
      return prev.map(item => {
        if (item.id === id && item.selectedVariant?.id === variantId) {
          const newQuantity = Math.max(0, item.quantity + change)
          return newQuantity === 0 ? null : { ...item, quantity: newQuantity }
        }
        return item
      }).filter(Boolean) as CartItem[]
    })
  }

  const removeFromCart = (id: number, variantId?: number) => {
    setCart(prev => prev.filter(item => 
      !(item.id === id && item.selectedVariant?.id === variantId)
    ))
  }

  const clearCart = () => {
    setCart([])
  }

  const getTotalPrice = () => {
    return cart.reduce((total, item) => total + (item.price * item.quantity), 0)
  }

  const getTotalItems = () => {
    return cart.reduce((total, item) => total + item.quantity, 0)
  }

  return {
    cart,
    addToCart,
    updateQuantity,
    removeFromCart,
    clearCart,
    getTotalPrice,
    getTotalItems
  }
}
