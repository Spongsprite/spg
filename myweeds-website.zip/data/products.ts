import { Product } from '../types'

export const categories = [
  {
    id: 1,
    name: { fr: 'Fleurs', en: 'Flowers', de: 'Blüten' },
    subcategories: [
      { id: 1, name: { fr: 'Indoor', en: 'Indoor', de: 'Indoor' }, categoryId: 1 },
      { id: 2, name: { fr: 'Outdoor', en: 'Outdoor', de: 'Outdoor' }, categoryId: 1 },
      { id: 3, name: { fr: 'Greenhouse', en: 'Greenhouse', de: 'Gewächshaus' }, categoryId: 1 }
    ]
  },
  {
    id: 2,
    name: { fr: 'Huiles CBD', en: 'CBD Oils', de: 'CBD Öle' },
    subcategories: [
      { id: 4, name: { fr: 'Full Spectrum', en: 'Full Spectrum', de: 'Vollspektrum' }, categoryId: 2 },
      { id: 5, name: { fr: 'Broad Spectrum', en: 'Broad Spectrum', de: 'Breitspektrum' }, categoryId: 2 },
      { id: 6, name: { fr: 'Isolat', en: 'Isolate', de: 'Isolat' }, categoryId: 2 }
    ]
  },
  {
    id: 3,
    name: { fr: 'Edibles', en: 'Edibles', de: 'Esswaren' },
    subcategories: [
      { id: 7, name: { fr: 'Gummies', en: 'Gummies', de: 'Gummibärchen' }, categoryId: 3 },
      { id: 8, name: { fr: 'Chocolats', en: 'Chocolates', de: 'Schokoladen' }, categoryId: 3 },
      { id: 9, name: { fr: 'Boissons', en: 'Drinks', de: 'Getränke' }, categoryId: 3 }
    ]
  }
]

export const products: Product[] = [
  {
    id: 1,
    name: {
      fr: 'Strain Premium',
      en: 'Premium Strain',
      de: 'Premium Sorte'
    },
    description: {
      fr: 'Cette variété haut de gamme offre une expérience premium, avec une saveur riche et des effets puissants',
      en: 'This top-shelf strain offers a premium experience, with a rich flavor and potent effects',
      de: 'Diese erstklassige Sorte bietet ein Premium-Erlebnis mit reichem Geschmack und starken Effekten'
    },
    price: 45.00,
    image: '/cannabis-bud.png',
    category: 'Fleurs',
    subcategory: 'Indoor',
    stock: 25,
    concentration: '22% CBD',
    effects: {
      fr: ['Relaxant', 'Anti-stress', 'Sommeil'],
      en: ['Relaxing', 'Anti-stress', 'Sleep'],
      de: ['Entspannend', 'Anti-Stress', 'Schlaf']
    },
    rating: 4.8,
    reviews: 124,
    isPopular: true,
    variants: [
      { id: 1, name: { fr: '1g', en: '1g', de: '1g' }, price: 45.00, stock: 25 },
      { id: 2, name: { fr: '3g', en: '3g', de: '3g' }, price: 120.00, stock: 15 },
      { id: 3, name: { fr: '5g', en: '5g', de: '5g' }, price: 180.00, stock: 8 }
    ]
  },
  {
    id: 2,
    name: {
      fr: 'Huile CBD Premium',
      en: 'Premium CBD Oil',
      de: 'Premium CBD Öl'
    },
    description: {
      fr: 'Le choix idéal pour un soulagement naturel, cette huile CBD full-spectrum offre des bienfaits apaisants',
      en: 'The ideal choice for natural relief, this full-spectrum CBD oil provides soothing benefits',
      de: 'Die ideale Wahl für natürliche Linderung, dieses Vollspektrum-CBD-Öl bietet beruhigende Vorteile'
    },
    price: 60.00,
    category: 'Huiles CBD',
    subcategory: 'Full Spectrum',
    stock: 15,
    concentration: '15% CBD',
    effects: {
      fr: ['Anti-inflammatoire', 'Relaxant', 'Bien-être'],
      en: ['Anti-inflammatory', 'Relaxing', 'Wellness'],
      de: ['Entzündungshemmend', 'Entspannend', 'Wohlbefinden']
    },
    rating: 4.9,
    reviews: 89,
    isNew: true,
    variants: [
      { id: 4, name: { fr: '10ml', en: '10ml', de: '10ml' }, price: 60.00, stock: 15 },
      { id: 5, name: { fr: '30ml', en: '30ml', de: '30ml' }, price: 150.00, stock: 8 }
    ]
  },
  {
    id: 3,
    name: {
      fr: 'Mélange Classique',
      en: 'Classic Blend',
      de: 'Klassische Mischung'
    },
    description: {
      fr: 'Un favori classique old-school, connu pour son arôme terreux et ses propriétés profondément calmantes',
      en: 'A classic, old-school favorite, known for its earthy aroma and deeply calming properties',
      de: 'Ein klassischer Old-School-Favorit, bekannt für sein erdiges Aroma und tiefgreifend beruhigende Eigenschaften'
    },
    price: 30.00,
    image: '/cannabis-jar.png',
    category: 'Fleurs',
    subcategory: 'Outdoor',
    stock: 5,
    concentration: '18% CBD',
    effects: {
      fr: ['Relaxant', 'Terreux', 'Classique'],
      en: ['Relaxing', 'Earthy', 'Classic'],
      de: ['Entspannend', 'Erdig', 'Klassisch']
    },
    rating: 4.6,
    reviews: 67,
    variants: [
      { id: 6, name: { fr: '1g', en: '1g', de: '1g' }, price: 30.00, stock: 5 },
      { id: 7, name: { fr: '3g', en: '3g', de: '3g' }, price: 80.00, stock: 2 }
    ]
  },
  {
    id: 4,
    name: {
      fr: 'Produit Sans Image',
      en: 'Product Without Image',
      de: 'Produkt Ohne Bild'
    },
    description: {
      fr: 'Un produit mystérieux sans image disponible',
      en: 'A mysterious product without available image',
      de: 'Ein mysteriöses Produkt ohne verfügbares Bild'
    },
    price: 25.00,
    category: 'Edibles',
    subcategory: 'Gummies',
    stock: 30,
    concentration: '10mg CBD/pièce',
    effects: {
      fr: ['Mystérieux', 'Discret', 'Longue durée'],
      en: ['Mysterious', 'Discreet', 'Long lasting'],
      de: ['Mysteriös', 'Diskret', 'Langanhaltend']
    },
    rating: 4.2,
    reviews: 45,
    isNew: true
  }
]
