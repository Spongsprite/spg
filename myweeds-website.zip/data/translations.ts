import { Translations } from '../types'

export const translations: Translations = {
  // Navigation
  home: { fr: 'Accueil', en: 'Home', de: 'Startseite' },
  shop: { fr: 'Boutique', en: 'Shop', de: 'Shop' },
  login: { fr: 'Connexion', en: 'Login', de: 'Anmelden' },
  faq: { fr: 'FAQ', en: 'FAQ', de: 'FAQ' },
  cart: { fr: 'Panier', en: 'Cart', de: 'Warenkorb' },
  
  // Shop
  searchProducts: { fr: 'Rechercher des produits...', en: 'Search products...', de: 'Produkte suchen...' },
  filters: { fr: 'Filtres', en: 'Filters', de: 'Filter' },
  category: { fr: 'Catégorie', en: 'Category', de: 'Kategorie' },
  allCategories: { fr: 'Toutes les catégories', en: 'All categories', de: 'Alle Kategorien' },
  price: { fr: 'Prix', en: 'Price', de: 'Preis' },
  sortBy: { fr: 'Trier par', en: 'Sort by', de: 'Sortieren nach' },
  popularity: { fr: 'Popularité', en: 'Popularity', de: 'Beliebtheit' },
  priceAsc: { fr: 'Prix croissant', en: 'Price ascending', de: 'Preis aufsteigend' },
  priceDesc: { fr: 'Prix décroissant', en: 'Price descending', de: 'Preis absteigend' },
  rating: { fr: 'Meilleures notes', en: 'Best rating', de: 'Beste Bewertung' },
  newest: { fr: 'Nouveautés', en: 'Newest', de: 'Neueste' },
  addToCart: { fr: 'Ajouter au panier', en: 'Add to cart', de: 'In den Warenkorb' },
  outOfStock: { fr: 'Rupture de stock', en: 'Out of stock', de: 'Ausverkauft' },
  lowStock: { fr: 'Stock faible', en: 'Low stock', de: 'Geringer Bestand' },
  
  // Login/Register
  email: { fr: 'Email', en: 'Email', de: 'E-Mail' },
  password: { fr: 'Mot de passe', en: 'Password', de: 'Passwort' },
  firstName: { fr: 'Prénom', en: 'First name', de: 'Vorname' },
  lastName: { fr: 'Nom', en: 'Last name', de: 'Nachname' },
  pseudonym: { fr: 'Pseudonyme', en: 'Pseudonym', de: 'Pseudonym' },
  signIn: { fr: 'Se connecter', en: 'Sign in', de: 'Anmelden' },
  signUp: { fr: 'S\'inscrire', en: 'Sign up', de: 'Registrieren' },
  forgotPassword: { fr: 'Mot de passe oublié ?', en: 'Forgot password?', de: 'Passwort vergessen?' },
  noAccount: { fr: 'Pas encore de compte ?', en: 'No account yet?', de: 'Noch kein Konto?' },
  
  // Checkout
  checkout: { fr: 'Commander', en: 'Checkout', de: 'Zur Kasse' },
  deliveryInfo: { fr: 'Informations de livraison', en: 'Delivery information', de: 'Lieferinformationen' },
  address: { fr: 'Adresse', en: 'Address', de: 'Adresse' },
  city: { fr: 'Ville', en: 'City', de: 'Stadt' },
  postalCode: { fr: 'Code postal', en: 'Postal code', de: 'Postleitzahl' },
  country: { fr: 'Pays', en: 'Country', de: 'Land' },
  switzerland: { fr: 'Suisse', en: 'Switzerland', de: 'Schweiz' },
  switzerlandOnly: { 
    fr: 'Livraison uniquement en Suisse. Pour l\'étranger, aucun remboursement n\'est effectué.',
    en: 'Delivery only in Switzerland. For abroad, no refund is made.',
    de: 'Lieferung nur in die Schweiz. Für das Ausland wird keine Rückerstattung geleistet.'
  },
  standardShipping: { fr: 'Livraison standard', en: 'Standard shipping', de: 'Standardversand' },
  expressShipping: { fr: 'Livraison express', en: 'Express shipping', de: 'Expressversand' },
  freeShipping: { fr: 'Livraison gratuite dès 50 CHF', en: 'Free shipping from 50 CHF', de: 'Kostenloser Versand ab 50 CHF' },
  
  // Payment
  payment: { fr: 'Paiement', en: 'Payment', de: 'Zahlung' },
  bankCard: { fr: 'Carte bancaire', en: 'Bank card', de: 'Bankkarte' },
  paypal: { fr: 'PayPal', en: 'PayPal', de: 'PayPal' },
  twint: { fr: 'TWINT', en: 'TWINT', de: 'TWINT' },
  
  // Common
  total: { fr: 'Total', en: 'Total', de: 'Gesamt' },
  subtotal: { fr: 'Sous-total', en: 'Subtotal', de: 'Zwischensumme' },
  shipping: { fr: 'Livraison', en: 'Shipping', de: 'Versand' },
  vat: { fr: 'TVA', en: 'VAT', de: 'MwSt' },
  confirm: { fr: 'Confirmer', en: 'Confirm', de: 'Bestätigen' },
  cancel: { fr: 'Annuler', en: 'Cancel', de: 'Abbrechen' },
  back: { fr: 'Retour', en: 'Back', de: 'Zurück' },
  continue: { fr: 'Continuer', en: 'Continue', de: 'Weiter' },
  
  // Error messages
  errorTitle: { fr: 'Erreur de paiement', en: 'Payment error', de: 'Zahlungsfehler' },
  errorMessage: { fr: 'Une erreur est survenue lors du paiement', en: 'An error occurred during payment', de: 'Bei der Zahlung ist ein Fehler aufgetreten' },
  
  // Success messages
  orderConfirmed: { fr: 'Commande confirmée', en: 'Order confirmed', de: 'Bestellung bestätigt' },
  thankYou: { fr: 'Merci pour votre commande !', en: 'Thank you for your order!', de: 'Vielen Dank für Ihre Bestellung!' }
}
