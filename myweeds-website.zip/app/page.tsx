'use client'

import { useState, useEffect, useCallback, useRef } from 'react'
import { Button } from '@/components/ui/button'
import { ShoppingCart, Plus, Minus, Search, Filter, Star, User, Menu, X, Mail, Send, Eye, EyeOff, Lightbulb } from 'lucide-react'
import { useCart } from '../hooks/useCart'
import { useSearch } from '../hooks/useSearch'
import { useLanguage } from '../hooks/useLanguage'
import { useAuth } from '../hooks/useAuth'
import { LanguageSelector } from '../components/LanguageSelector'
import { StarRating } from '../components/StarRating'
import { SkullIcon } from '../components/SkullIcon'
import { products, categories } from '../data/products'
import { translations } from '../data/translations'
import { Product, Language } from '../types'

export default function MyWeedsApp() {
  const [currentPage, setCurrentPage] = useState<'home' | 'shop' | 'login' | 'register' | 'forgot-password' | 'reset-password' | 'faq' | 'checkout' | 'success' | 'error'>('home')
  const [showFilters, setShowFilters] = useState(false)
  const [showMobileMenu, setShowMobileMenu] = useState(false)
  const [checkoutStep, setCheckoutStep] = useState(1)
  const [resetCode, setResetCode] = useState('')
  const [newPassword, setNewPassword] = useState('')
  const [supportMessage, setSupportMessage] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [showNewPassword, setShowNewPassword] = useState(false)
  const [isTransitioning, setIsTransitioning] = useState(false)
  
  // Forms - Stabilized with useCallback
  const [loginForm, setLoginForm] = useState({ email: '', password: '' })
  const [registerForm, setRegisterForm] = useState({
    firstName: '', lastName: '', pseudonym: '', email: '', password: ''
  })
  const [checkoutForm, setCheckoutForm] = useState({
    firstName: '', lastName: '', email: '', address: '', city: '', postalCode: '', 
    country: 'CH', shippingMethod: 'standard', paymentMethod: 'card'
  })

  // Refs for inputs to prevent focus loss
  const searchInputRef = useRef<HTMLInputElement>(null)

  const { cart, addToCart, updateQuantity, removeFromCart, clearCart, getTotalPrice, getTotalItems } = useCart()
  const { language, changeLanguage } = useLanguage()
  const { user, isLoading, register, login, logout, sendPasswordReset, resetPassword } = useAuth()
  const {
    searchTerm, setSearchTerm, selectedCategory, setSelectedCategory,
    minPrice, setMinPrice, maxPrice, setMaxPrice, sortBy, setSortBy, filteredProducts
  } = useSearch(products, language)

  const t = (key: string) => translations[key]?.[language] || key

  const changePage = useCallback((newPage: typeof currentPage) => {
    setIsTransitioning(true)
    setTimeout(() => {
      setCurrentPage(newPage)
      setTimeout(() => setIsTransitioning(false), 100)
    }, 200)
  }, [])

  // Stars animation component
  const AnimatedStars = () => {
    const [stars, setStars] = useState<Array<{id: number, x: number, y: number, size: number, speed: number}>>([])

    useEffect(() => {
      const generateStars = () => {
        const newStars = []
        for (let i = 0; i < 100; i++) {
          newStars.push({
            id: i,
            x: Math.random() * 100,
            y: Math.random() * 100,
            size: Math.random() * 3 + 1,
            speed: Math.random() * 0.5 + 0.1
          })
        }
        setStars(newStars)
      }

      generateStars()

      const interval = setInterval(() => {
        setStars(prevStars => 
          prevStars.map(star => ({
            ...star,
            x: (star.x + star.speed) % 100
          }))
        )
      }, 50)

      return () => clearInterval(interval)
    }, [])

    return (
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {stars.map(star => (
          <div
            key={star.id}
            className="absolute bg-white rounded-full animate-pulse"
            style={{
              left: `${star.x}%`,
              top: `${star.y}%`,
              width: `${star.size}px`,
              height: `${star.size}px`,
              boxShadow: `0 0 ${star.size * 2}px rgba(255, 255, 255, 0.8)`
            }}
          />
        ))}
      </div>
    )
  }

// Abandoned neon tubes component
const AbandonedNeonTubes = () => {
  const [tubeStates, setTubeStates] = useState([true, false, true])

  useEffect(() => {
    // Tube 1 - flickers every 1-3 seconds
    const tube1Interval = setInterval(() => {
      setTubeStates(prev => {
        const newStates = [...prev]
        newStates[0] = Math.random() > 0.3 // 70% chance to be on
        return newStates
      })
    }, Math.random() * 2000 + 1000)

    // Tube 2 - flickers every 0.5-2 seconds (more erratic)
    const tube2Interval = setInterval(() => {
      setTubeStates(prev => {
        const newStates = [...prev]
        newStates[1] = Math.random() > 0.5 // 50% chance to be on
        return newStates
      })
    }, Math.random() * 1500 + 500)

    // Tube 3 - flickers every 2-4 seconds (slower)
    const tube3Interval = setInterval(() => {
      setTubeStates(prev => {
        const newStates = [...prev]
        newStates[2] = Math.random() > 0.4 // 60% chance to be on
        return newStates
      })
    }, Math.random() * 2000 + 2000)

    return () => {
      clearInterval(tube1Interval)
      clearInterval(tube2Interval)
      clearInterval(tube3Interval)
    }
  }, [])

  const tubes = [
    { x: 'left-8', y: 'bottom-12', rotation: 'rotate-12' },
    { x: 'left-24', y: 'bottom-8', rotation: '-rotate-6' },
    { x: 'left-40', y: 'bottom-16', rotation: 'rotate-3' }
  ]

  return (
    <div className="fixed z-20">
      {tubes.map((tube, index) => (
        <div
          key={index}
          className={`absolute ${tube.x} ${tube.y} ${tube.rotation} transition-all duration-200`}
        >
          {/* Neon glow effect */}
          {tubeStates[index] && (
            <div className="absolute inset-0 bg-red-500 rounded-full blur-md opacity-60 scale-110" />
          )}
          
          {/* Neon tube */}
          <div
            className={`relative z-10 w-24 h-3 rounded-full border transition-all duration-100 ${
              tubeStates[index]
                ? 'bg-red-500 border-red-400 shadow-lg shadow-red-500/50'
                : 'bg-gray-800 border-gray-600'
            }`}
          >
            {/* Inner light */}
            {tubeStates[index] && (
              <div className="absolute inset-1 bg-red-300 rounded-full opacity-80" />
            )}
          </div>
          
          {/* Tube ends */}
          <div className="absolute -left-1 top-0 w-2 h-3 bg-gray-700 rounded-l-full border border-gray-600" />
          <div className="absolute -right-1 top-0 w-2 h-3 bg-gray-700 rounded-r-full border border-gray-600" />
          
          {/* Broken wire effect */}
          <div className="absolute -top-2 left-1/2 w-px h-2 bg-gray-600 transform -translate-x-1/2" />
        </div>
      ))}
    </div>
  )
}

  const HomePage = () => (
    <div className="min-h-screen relative overflow-hidden">
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{ 
          backgroundImage: "url('/fond-accueil.png')"
        }}
      />
      <div className="absolute inset-0 bg-black/40" />
      
      {/* Animated Stars */}
      <AnimatedStars />
      
      <div className="relative z-10 min-h-screen flex flex-col">
        <div className="p-4 flex justify-between items-center">
          <LanguageSelector currentLanguage={language} onLanguageChange={changeLanguage} />
          
          <div className="md:hidden">
            <Button
              onClick={() => setShowMobileMenu(!showMobileMenu)}
              className="bg-gray-800/80 text-white border-none"
            >
              {showMobileMenu ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </Button>
          </div>
        </div>

        {showMobileMenu && (
          <div className="md:hidden absolute inset-0 bg-black/90 z-40 flex flex-col items-center justify-center space-y-6">
            <Button
              onClick={() => { changePage('login'); setShowMobileMenu(false) }}
              className="bg-transparent border-2 border-cyan-400 text-cyan-400 hover:bg-cyan-400 hover:text-black px-8 py-3 text-lg glow-cyan"
            >
              {t('login')}
            </Button>
            <Button
              onClick={() => { changePage('shop'); setShowMobileMenu(false) }}
              className="bg-transparent border-2 border-cyan-400 text-cyan-400 hover:bg-cyan-400 hover:text-black px-8 py-3 text-lg glow-cyan"
            >
              {t('shop')}
            </Button>
            <Button
              onClick={() => { changePage('faq'); setShowMobileMenu(false) }}
              className="bg-transparent border-2 border-cyan-400 text-cyan-400 hover:bg-cyan-400 hover:text-black px-8 py-3 text-lg glow-cyan"
            >
              {t('faq')}
            </Button>
          </div>
        )}

        <div className="flex-1 flex items-center justify-center px-4">
          <div className="text-center">
            <h1 
              className="text-6xl md:text-8xl font-black text-transparent bg-gradient-to-r from-yellow-400 via-orange-500 to-yellow-600 bg-clip-text tracking-wider mb-12 glow-yellow"
            >
              MYWEED'S
            </h1>
            
            <div className="hidden md:flex justify-center gap-6">
              <Button
                onClick={() => changePage('login')}
                className="bg-transparent border-2 border-cyan-400 text-cyan-400 hover:bg-cyan-400 hover:text-black px-8 py-3 text-lg transition-all duration-300 glow-cyan"
              >
                {t('login')}
              </Button>
              <Button
                onClick={() => changePage('shop')}
                className="bg-transparent border-2 border-cyan-400 text-cyan-400 hover:bg-cyan-400 hover:text-black px-8 py-3 text-lg transition-all duration-300 glow-cyan"
              >
                {t('shop')}
              </Button>
              <Button
                onClick={() => changePage('faq')}
                className="bg-transparent border-2 border-cyan-400 text-cyan-400 hover:bg-cyan-400 hover:text-black px-8 py-3 text-lg transition-all duration-300 glow-cyan"
              >
                {t('faq')}
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )

  const ShopPage = () => {
    return (
      <div className="min-h-screen relative">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{ 
            backgroundImage: "url('/fond-shop.png')"
          }}
        />
        <div className="absolute inset-0 bg-black/60" />
        
        
        
        {/* Abandoned Neon Tubes - Bottom left */}
        <AbandonedNeonTubes />
        
        <div className="relative z-10 text-white">
          
          <div className="bg-gray-900/50 p-4 border-b border-gray-800">
            <div className="max-w-7xl mx-auto flex items-center justify-between">
              <div className="flex items-center gap-4">
                <img 
                  src="/cannabis-character.gif" 
                  alt="Cannabis Character" 
                  className="w-12 h-auto opacity-90 hover:opacity-100 transition-opacity duration-300"
                />
                <h1
                  className="text-2xl md:text-4xl font-black text-transparent bg-gradient-to-r from-green-400 to-green-600 bg-clip-text cursor-pointer glow-green"
                  onClick={() => changePage('home')}
                >
                  MYWEED'S
                </h1>
              </div>
              
              <div className="flex items-center gap-4">
                <LanguageSelector currentLanguage={language} onLanguageChange={changeLanguage} />
                
                {user && (
                  <div className="hidden md:flex items-center gap-2 text-sm">
                    <User className="w-4 h-4 text-green-400" />
                    <span className="text-green-400 glow-green">{user.pseudonym}</span>
                    <span className="text-yellow-400 glow-yellow">({user.loyaltyPoints} pts)</span>
                  </div>
                )}
                
                <Button
                  onClick={() => changePage('checkout')}
                  className="flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white border-2 border-green-400 font-bold transition-all duration-300"
                >
                  <ShoppingCart className="w-4 h-4" />
                  <span className="hidden md:inline">{t('cart')}</span>
                  <span className="bg-yellow-400 text-black rounded-full px-2 py-1 text-xs font-bold">
                    {getTotalItems()}
                  </span>
                </Button>
              </div>
            </div>
          </div>

          <div className="max-w-7xl mx-auto p-4"> {/* Added left margin for GIF */}
            {/* Search - FIXED INPUT WITH REF */}
            <div className="relative mb-6">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4 pointer-events-none" />
              <input
                ref={searchInputRef}
                type="text"
                placeholder={t('searchProducts')}
                value={searchTerm}
                onChange={(e) => {
                  e.preventDefault()
                  setSearchTerm(e.target.value)
                }}
                onKeyDown={(e) => {
                  // Prevent any unwanted form submission
                  if (e.key === 'Enter') {
                    e.preventDefault()
                    searchInputRef.current?.blur()
                  }
                }}
                className="w-full pl-10 pr-4 py-3 bg-gray-800 border-2 border-gray-600 rounded-lg focus:border-green-400 focus:outline-none text-white transition-all duration-200"
                autoComplete="off"
              />
            </div>

            <div className="flex flex-col lg:flex-row gap-6">
              {/* Filters - Always visible on desktop */}
              <div className="lg:w-64 space-y-6">
                <div className="bg-gray-900/80 p-4 rounded-lg border-2 border-green-500/30">
                  <h3 className="text-lg font-bold text-green-400 mb-4 glow-green">{t('filters')}</h3>
                  
                  <div className="mb-4">
                    <label className="block text-sm font-medium mb-2">{t('category')}</label>
                    <select
                      value={selectedCategory}
                      onChange={(e) => setSelectedCategory(e.target.value)}
                      className="w-full p-3 bg-gray-800 border-2 border-gray-600 rounded-lg focus:border-green-400 focus:outline-none text-white transition-all duration-200"
                    >
                      <option value="">{t('allCategories')}</option>
                      {categories.map(cat => (
                        <option key={cat.id} value={cat.name.fr}>{cat.name[language]}</option>
                      ))}
                    </select>
                  </div>

                  <div className="mb-4">
                    <label className="block text-sm font-medium mb-2 glow-green">{t('price')} (CHF)</label>
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="block text-xs text-gray-400 mb-1">Min</label>
                        <input
                          type="number"
                          min="0"
                          max="200"
                          value={minPrice}
                          onChange={(e) => setMinPrice(Math.max(0, parseInt(e.target.value) || 0))}
                          className="w-full p-3 bg-gray-800 border-2 border-gray-600 rounded-lg focus:border-green-400 focus:outline-none text-white transition-all duration-200 text-sm"
                          placeholder="0"
                        />
                      </div>
                      <div>
                        <label className="block text-xs text-gray-400 mb-1">Max</label>
                        <input
                          type="number"
                          min="0"
                          max="200"
                          value={maxPrice}
                          onChange={(e) => setMaxPrice(Math.min(200, parseInt(e.target.value) || 200))}
                          className="w-full p-3 bg-gray-800 border-2 border-gray-600 rounded-lg focus:border-green-400 focus:outline-none text-white transition-all duration-200 text-sm"
                          placeholder="200"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="mb-4">
                    <label className="block text-sm font-medium mb-2">{t('sortBy')}</label>
                    <select
                      value={sortBy}
                      onChange={(e) => setSortBy(e.target.value as any)}
                      className="w-full p-3 bg-gray-800 border-2 border-gray-600 rounded-lg focus:border-green-400 focus:outline-none text-white transition-all duration-200"
                    >
                      <option value="popularity">{t('popularity')}</option>
                      <option value="price-asc">{t('priceAsc')}</option>
                      <option value="price-desc">{t('priceDesc')}</option>
                      <option value="rating">{t('rating')}</option>
                      <option value="newest">{t('newest')}</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Products */}
              <div className="flex-1">
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                  {filteredProducts.map((product) => (
                    <div key={product.id} className="bg-gray-900/80 rounded-lg p-4 hover:bg-gray-900/90 transition-all duration-300 border-2 border-gray-700 hover:border-green-500">
                      <div className="relative mb-4">
                        {product.image ? (
                          <img
                            src={product.image || "/placeholder.svg"}
                            alt={product.name[language]}
                            className="w-full h-48 object-cover rounded-lg border-2 border-gray-600"
                          />
                        ) : (
                          <SkullIcon className="w-full h-48" />
                        )}
                        
                        {product.isNew && (
                          <span className="absolute top-2 left-2 bg-green-500 text-black px-2 py-1 rounded text-xs font-bold border-2 border-green-400">
                            NOUVEAU
                          </span>
                        )}
                        {product.stock <= 5 && (
                          <span className="absolute bottom-2 left-2 bg-red-500 text-white px-2 py-1 rounded text-xs font-bold border-2 border-red-400 glow-red">
                            {t('lowStock')}: {product.stock}
                          </span>
                        )}
                      </div>

                      <div className="space-y-3">
                        <div>
                          <h3 className="text-lg font-bold text-yellow-400 mb-1 glow-yellow">
                            {product.name[language]}
                          </h3>
                          <p className="text-gray-300 text-sm line-clamp-2">
                            {product.description[language]}
                          </p>
                        </div>

                        <div className="flex items-center gap-2">
                          <StarRating 
                            rating={product.rating} 
                            interactive={true}
                            onRatingChange={(rating) => {
                              console.log(`New rating for ${product.name[language]}: ${rating}`)
                            }}
                          />
                          <span className="text-sm text-gray-400">({product.reviews})</span>
                        </div>

                        {product.effects && (
                          <div className="flex flex-wrap gap-1">
                            {product.effects[language]?.slice(0, 3).map((effect, index) => (
                              <span
                                key={index}
                                className="bg-green-600/20 text-green-400 px-2 py-1 rounded text-xs border border-green-500"
                              >
                                {effect}
                              </span>
                            ))}
                          </div>
                        )}

                        <div className="flex items-center justify-between">
                          <div className="text-2xl font-bold text-green-400 glow-green">
                            {product.price.toFixed(2)} CHF
                          </div>
                          <Button
                            onClick={() => addToCart(product)}
                            disabled={product.stock === 0}
                            className="bg-green-600 hover:bg-green-700 text-white border-2 border-green-400 font-bold transition-all duration-300"
                          >
                            {product.stock === 0 ? t('outOfStock') : t('addToCart')}
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }

  const LoginPage = () => (
    <div className="min-h-screen bg-black text-white flex items-center justify-center p-4">
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{ 
          backgroundImage: "url('/fond-shop.png')"
        }}
      />
      <div className="bg-gray-900 p-8 rounded-lg w-full max-w-md border-2 border-green-500/30 relative z-10">
        
        <div className="flex items-center justify-center gap-4 mb-8">
          <img 
            src="/cannabis-character.gif" 
            alt="Cannabis Character" 
            className="w-12 h-auto opacity-90 hover:opacity-100 transition-opacity duration-300"
          />
          <h1
            className="text-4xl font-black text-transparent bg-gradient-to-r from-green-400 to-green-600 bg-clip-text cursor-pointer glow-green"
            onClick={() => changePage('home')}
          >
            MYWEED'S
          </h1>
        </div>
        
        <div className="mb-6">
          <LanguageSelector currentLanguage={language} onLanguageChange={changeLanguage} />
        </div>

        <h2 className="text-2xl font-bold text-center mb-6 glow-cyan">{t('signIn')}</h2>

        <form onSubmit={async (e) => {
          e.preventDefault()
          const result = await login(loginForm.email, loginForm.password)
          if (result.success) {
            changePage('shop')
          }
        }} className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-2">{t('email')}</label>
            <input
              type="email"
              value={loginForm.email}
              onChange={(e) => {
                e.preventDefault()
                setLoginForm(prev => ({ ...prev, email: e.target.value }))
              }}
              className="w-full p-3 bg-gray-800 border-2 border-gray-600 rounded-lg focus:border-green-400 focus:outline-none text-white transition-all duration-200"
              required
              autoComplete="email"
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-2">{t('password')}</label>
            <div className="relative">
              <input
                type={showPassword ? "text" : "password"}
                value={loginForm.password}
                onChange={(e) => {
                  e.preventDefault()
                  setLoginForm(prev => ({ ...prev, password: e.target.value }))
                }}
                className="w-full p-3 bg-gray-800 border-2 border-gray-600 rounded-lg focus:border-green-400 focus:outline-none text-white transition-all duration-200 pr-10"
                required
                autoComplete="current-password"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-white"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>
          
          <Button 
            type="submit" 
            disabled={isLoading}
            className="w-full bg-green-600 hover:bg-green-700 text-white border-2 border-green-400 font-bold transition-all duration-300"
          >
            {isLoading ? 'CONNEXION...' : t('signIn')}
          </Button>
        </form>

        <div className="mt-6 text-center space-y-2">
          <button
            onClick={() => changePage('forgot-password')}
            className="text-cyan-400 hover:text-cyan-300 text-sm glow-cyan"
          >
            {t('forgotPassword')}
          </button>
          
          <p className="text-gray-400 text-sm">
            {t('noAccount')}{' '}
            <button
              onClick={() => changePage('register')}
              className="text-green-400 hover:text-green-300 glow-green"
            >
              {t('signUp')}
            </button>
          </p>
        </div>

        <Button
          onClick={() => changePage('home')}
          className="w-full mt-4 bg-transparent border-2 border-cyan-400 text-cyan-400 hover:bg-cyan-400 hover:text-black"
        >
          {t('back')}
        </Button>
      </div>
    </div>
  )

  const RegisterPage = () => (
    <div className="min-h-screen bg-black text-white flex items-center justify-center p-4">
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{ 
          backgroundImage: "url('/fond-shop.png')"
        }}
      />
      <div className="bg-gray-900 p-8 rounded-lg w-full max-w-md border-2 border-green-500/30 relative z-10">
        
        <div className="flex items-center justify-center gap-4 mb-8">
          <img 
            src="/cannabis-character.gif" 
            alt="Cannabis Character" 
            className="w-12 h-auto opacity-90 hover:opacity-100 transition-opacity duration-300"
          />
          <h1
            className="text-4xl font-black text-transparent bg-gradient-to-r from-green-400 to-green-600 bg-clip-text cursor-pointer glow-green"
            onClick={() => changePage('home')}
          >
            MYWEED'S
          </h1>
        </div>

        <h2 className="text-2xl font-bold text-center mb-6 glow-cyan">{t('signUp')}</h2>

        <form onSubmit={async (e) => {
          e.preventDefault()
          const result = await register(registerForm)
          if (result.success) {
            changePage('shop')
          }
        }} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-2">{t('firstName')}</label>
              <input
                type="text"
                value={registerForm.firstName}
                onChange={(e) => {
                  e.preventDefault()
                  setRegisterForm(prev => ({ ...prev, firstName: e.target.value }))
                }}
                className="w-full p-3 bg-gray-800 border-2 border-gray-600 rounded-lg focus:border-green-400 focus:outline-none text-white transition-all duration-200"
                required
                autoComplete="given-name"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">{t('lastName')}</label>
              <input
                type="text"
                value={registerForm.lastName}
                onChange={(e) => {
                  e.preventDefault()
                  setRegisterForm(prev => ({ ...prev, lastName: e.target.value }))
                }}
                className="w-full p-3 bg-gray-800 border-2 border-gray-600 rounded-lg focus:border-green-400 focus:outline-none text-white transition-all duration-200"
                required
                autoComplete="family-name"
              />
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-2">{t('pseudonym')}</label>
            <input
              type="text"
              value={registerForm.pseudonym}
              onChange={(e) => {
                e.preventDefault()
                setRegisterForm(prev => ({ ...prev, pseudonym: e.target.value }))
              }}
              className="w-full p-3 bg-gray-800 border-2 border-gray-600 rounded-lg focus:border-green-400 focus:outline-none text-white transition-all duration-200"
              required
              autoComplete="username"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-2">{t('email')}</label>
            <input
              type="email"
              value={registerForm.email}
              onChange={(e) => {
                e.preventDefault()
                setRegisterForm(prev => ({ ...prev, email: e.target.value }))
              }}
              className="w-full p-3 bg-gray-800 border-2 border-gray-600 rounded-lg focus:border-green-400 focus:outline-none text-white transition-all duration-200"
              required
              autoComplete="email"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-2">{t('password')}</label>
            <div className="relative">
              <input
                type={showPassword ? "text" : "password"}
                value={registerForm.password}
                onChange={(e) => {
                  e.preventDefault()
                  setRegisterForm(prev => ({ ...prev, password: e.target.value }))
                }}
                className="w-full p-3 bg-gray-800 border-2 border-gray-600 rounded-lg focus:border-green-400 focus:outline-none text-white transition-all duration-200 pr-10"
                required
                autoComplete="new-password"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-white"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>
          
          <Button 
            type="submit" 
            disabled={isLoading}
            className="w-full bg-green-600 hover:bg-green-700 text-white border-2 border-green-400 font-bold transition-all duration-300"
          >
            {isLoading ? 'INSCRIPTION...' : t('signUp')}
          </Button>
        </form>

        <div className="mt-6 text-center">
          <button
            onClick={() => changePage('login')}
            className="text-green-400 hover:text-green-300 glow-green"
          >
            Déjà un compte ? Se connecter
          </button>
        </div>
      </div>
    </div>
  )

  const ForgotPasswordPage = () => (
    <div className="min-h-screen bg-black text-white flex items-center justify-center p-4">
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{ 
          backgroundImage: "url('/fond-shop.png')"
        }}
      />
      <div className="bg-gray-900 p-8 rounded-lg w-full max-w-md border-2 border-green-500/30 relative z-10">
        
        <div className="flex items-center justify-center gap-4 mb-6">
          <img 
            src="/cannabis-character.gif" 
            alt="Cannabis Character" 
            className="w-10 h-auto opacity-90 hover:opacity-100 transition-opacity duration-300"
          />
          <h2 className="text-2xl font-bold text-center glow-cyan">MOT DE PASSE OUBLIÉ</h2>
        </div>
        
        <form onSubmit={async (e) => {
          e.preventDefault()
          const result = await sendPasswordReset(loginForm.email)
          if (result.success) {
            changePage('reset-password')
          }
        }} className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-2">{t('email')}</label>
            <input
              type="email"
              value={loginForm.email}
              onChange={(e) => {
                e.preventDefault()
                setLoginForm(prev => ({ ...prev, email: e.target.value }))
              }}
              className="w-full p-3 bg-gray-800 border-2 border-gray-600 rounded-lg focus:border-green-400 focus:outline-none text-white transition-all duration-200"
              required
              autoComplete="email"
            />
          </div>
          
          <Button 
            type="submit" 
            disabled={isLoading}
            className="w-full bg-green-600 hover:bg-green-700 text-white border-2 border-green-400 font-bold transition-all duration-300"
          >
            {isLoading ? 'ENVOI...' : 'ENVOYER LE CODE'}
          </Button>
        </form>

        <Button
          onClick={() => changePage('login')}
          className="w-full mt-4 bg-transparent border-2 border-cyan-400 text-cyan-400 hover:bg-cyan-400 hover:text-black"
        >
          {t('back')}
        </Button>
      </div>
    </div>
  )

  const ResetPasswordPage = () => (
    <div className="min-h-screen bg-black text-white flex items-center justify-center p-4">
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{ 
          backgroundImage: "url('/fond-shop.png')"
        }}
      />
      <div className="bg-gray-900 p-8 rounded-lg w-full max-w-md border-2 border-green-500/30 relative z-10">
        
        <div className="flex items-center justify-center gap-4 mb-6">
          <img 
            src="/cannabis-character.gif" 
            alt="Cannabis Character" 
            className="w-10 h-auto opacity-90 hover:opacity-100 transition-opacity duration-300"
          />
          <h2 className="text-2xl font-bold text-center glow-cyan">NOUVEAU MOT DE PASSE</h2>
        </div>
        
        <form onSubmit={async (e) => {
          e.preventDefault()
          const result = await resetPassword(resetCode, newPassword)
          if (result.success) {
            changePage('login')
          }
        }} className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-2">CODE DE RÉCUPÉRATION</label>
            <input
              type="text"
              value={resetCode}
              onChange={(e) => {
                e.preventDefault()
                setResetCode(e.target.value)
              }}
              className="w-full p-3 bg-gray-800 border-2 border-gray-600 rounded-lg focus:border-green-400 focus:outline-none text-white transition-all duration-200"
              required
              autoComplete="one-time-code"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-2">NOUVEAU MOT DE PASSE</label>
            <div className="relative">
              <input
                type={showNewPassword ? "text" : "password"}
                value={newPassword}
                onChange={(e) => {
                  e.preventDefault()
                  setNewPassword(e.target.value)
                }}
                className="w-full p-3 bg-gray-800 border-2 border-gray-600 rounded-lg focus:border-green-400 focus:outline-none text-white transition-all duration-200 pr-10"
                required
                autoComplete="new-password"
              />
              <button
                type="button"
                onClick={() => setShowNewPassword(!showNewPassword)}
                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-white"
              >
                {showNewPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>
          
          <Button 
            type="submit" 
            disabled={isLoading}
            className="w-full bg-green-600 hover:bg-green-700 text-white border-2 border-green-400 font-bold transition-all duration-300"
          >
            {isLoading ? 'RÉINITIALISATION...' : 'RÉINITIALISER'}
          </Button>
        </form>
      </div>
    </div>
  )

  const FAQPage = () => (
    <div className="min-h-screen relative">
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{ 
          backgroundImage: "url('/fond-shop.png')"
        }}
      />
      <div className="absolute inset-0 bg-black/50" />
      
      <div className="relative z-10 text-white">
        
        <div className="p-6 border-b border-gray-800 bg-gray-900/50">
          <div className="flex items-center justify-between max-w-6xl mx-auto">
            <div className="flex items-center gap-4">
              <img 
                src="/cannabis-character.gif" 
                alt="Cannabis Character" 
                className="w-12 h-auto opacity-90 hover:opacity-100 transition-opacity duration-300"
              />
              <h1
                className="text-4xl font-black text-transparent bg-gradient-to-r from-green-400 to-green-600 bg-clip-text cursor-pointer glow-green"
                onClick={() => changePage('home')}
              >
                MYWEED'S
              </h1>
            </div>
            <LanguageSelector currentLanguage={language} onLanguageChange={changeLanguage} />
          </div>
        </div>

        <div className="max-w-4xl mx-auto p-6">
          <div className="text-center mb-12">
            <h2 className="text-5xl font-black text-transparent bg-gradient-to-r from-yellow-400 to-orange-500 bg-clip-text mb-4 glow-yellow">
              FAQ
            </h2>
            <p className="text-gray-300 text-lg">
              TROUVEZ RAPIDEMENT LES RÉPONSES À VOS QUESTIONS
            </p>
          </div>

          {/* FAQ Content */}
          <div className="space-y-8 mb-12">
            <div className="bg-gray-900/80 rounded-lg p-6 border-2 border-green-500/20">
              <h3 className="text-2xl font-bold text-green-400 mb-6 glow-green">COMMANDES & PAIEMENTS</h3>
              <div className="space-y-4">
                <div className="border-b border-gray-700 pb-4">
                  <h4 className="text-lg font-bold text-white mb-2">QUELS MOYENS DE PAIEMENT ACCEPTEZ-VOUS ?</h4>
                  <p className="text-gray-300">Nous acceptons les cartes bancaires (Visa, Mastercard), PayPal et TWINT pour la Suisse.</p>
                </div>
                <div className="border-b border-gray-700 pb-4">
                  <h4 className="text-lg font-bold text-white mb-2">MES PAIEMENTS SONT-ILS SÉCURISÉS ?</h4>
                  <p className="text-gray-300">Oui, tous nos paiements sont chiffrés SSL et apparaissent discrètement sur vos relevés.</p>
                </div>
              </div>
            </div>

            <div className="bg-gray-900/80 rounded-lg p-6 border-2 border-green-500/20">
              <h3 className="text-2xl font-bold text-green-400 mb-6 glow-green">LIVRAISON</h3>
              <div className="space-y-4">
                <div className="border-b border-gray-700 pb-4">
                  <h4 className="text-lg font-bold text-white mb-2">LIVREZ-VOUS UNIQUEMENT EN SUISSE ?</h4>
                  <p className="text-gray-300">Oui, nous livrons uniquement en Suisse. Livraison gratuite dès 50 CHF.</p>
                </div>
                <div>
                  <h4 className="text-lg font-bold text-white mb-2">COMBIEN DE TEMPS PREND LA LIVRAISON ?</h4>
                  <p className="text-gray-300">2-3 jours ouvrés en standard, 24-48h en express.</p>
                </div>
              </div>
            </div>

            <div className="bg-gray-900/80 rounded-lg p-6 border-2 border-green-500/20">
              <h3 className="text-2xl font-bold text-green-400 mb-6 glow-green">PRODUITS</h3>
              <div className="space-y-4">
                <div className="border-b border-gray-700 pb-4">
                  <h4 className="text-lg font-bold text-white mb-2">VOS PRODUITS SONT-ILS LÉGAUX EN SUISSE ?</h4>
                  <p className="text-gray-300">Oui, tous nos produits respectent la législation suisse avec un taux de THC inférieur à 1%.</p>
                </div>
                <div>
                  <h4 className="text-lg font-bold text-white mb-2">COMMENT CONSERVER MES PRODUITS ?</h4>
                  <p className="text-gray-300">Conservez vos produits dans un endroit frais, sec et à l'abri de la lumière.</p>
                </div>
              </div>
            </div>

            <div className="bg-gray-900/80 rounded-lg p-6 border-2 border-green-500/20">
              <h3 className="text-2xl font-bold text-green-400 mb-6 glow-green">CONFIDENTIALITÉ</h3>
              <div className="space-y-4">
                <div className="border-b border-gray-700 pb-4">
                  <h4 className="text-lg font-bold text-white mb-2">MES DONNÉES SONT-ELLES PROTÉGÉES ?</h4>
                  <p className="text-gray-300">Absolument. Nous respectons le RGPD et ne partageons jamais vos données personnelles.</p>
                </div>
                <div>
                  <h4 className="text-lg font-bold text-white mb-2">L'EMBALLAGE EST-IL DISCRET ?</h4>
                  <p className="text-gray-300">Oui, tous nos colis sont expédiés dans un emballage neutre et discret.</p>
                </div>
              </div>
            </div>
          </div>

          {/* Contact Support - FIXED EMAIL */}
          <div className="bg-gray-900/80 rounded-lg p-6 border-2 border-cyan-500/20">
            <h3 className="text-2xl font-bold text-cyan-400 mb-6 glow-cyan">CONTACTEZ LE SUPPORT</h3>
            
            <form onSubmit={(e) => {
              e.preventDefault()
              window.location.href = `mailto:Bilal.ghanmi1@gmail.com?subject=Support MyWeed's&body=${encodeURIComponent(supportMessage)}`
              setSupportMessage('')
              alert('MESSAGE ENVOYÉ AU SUPPORT !')
            }} className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">VOTRE MESSAGE</label>
                <textarea
                  value={supportMessage}
                  onChange={(e) => {
                    e.preventDefault()
                    setSupportMessage(e.target.value)
                  }}
                  rows={5}
                  className="w-full p-3 bg-gray-800 border-2 border-gray-600 rounded-lg focus:border-green-400 focus:outline-none text-white resize-none transition-all duration-200"
                  placeholder="Décrivez votre problème ou votre question..."
                  required
                />
              </div>
              
              <Button 
                type="submit"
                className="w-full bg-cyan-600 hover:bg-cyan-700 text-white font-bold transition-all duration-300 flex items-center justify-center gap-2 border-2 border-cyan-400"
              >
                <Send className="w-4 h-4" />
                ENVOYER AU SUPPORT
              </Button>
            </form>
          </div>
        </div>
      </div>
    </div>
  )

  const CheckoutPage = () => {
    const isFormValid = checkoutForm.firstName && checkoutForm.lastName && 
                       checkoutForm.email && checkoutForm.address && 
                       checkoutForm.city && checkoutForm.postalCode

    const shippingCost = checkoutForm.shippingMethod === 'express' ? 12.90 : 
                        getTotalPrice() >= 50 ? 0 : 5.90
    const vatAmount = getTotalPrice() * 0.077
    const finalTotal = getTotalPrice() + shippingCost + vatAmount

    return (
      <div className="min-h-screen bg-black text-white">
        <div
        className="absolute inset-0 bg-cover bg-center"
        style={{ 
          backgroundImage: "url('/fond-shop.png')"
        }}
      />
        
        <div className="p-6 border-b border-gray-800 relative z-10">
          <div className="flex items-center gap-4">
            <img 
              src="/cannabis-character.gif" 
              alt="Cannabis Character" 
              className="w-12 h-auto opacity-90 hover:opacity-100 transition-opacity duration-300"
            />
            <h1
              className="text-4xl font-black text-transparent bg-gradient-to-r from-green-400 to-green-600 bg-clip-text cursor-pointer glow-green"
              onClick={() => changePage('home')}
            >
              MYWEED'S
            </h1>
          </div>
        </div>

        <div className="max-w-6xl mx-auto p-6 relative z-10">
          {/* Steps */}
          <div className="flex items-center justify-center mb-8">
            <div className="flex items-center space-x-4">
              {[1, 2, 3].map((step) => (
                <div key={step} className="flex items-center">
                  <div
                    className={`w-10 h-10 rounded-full flex items-center justify-center font-bold border-2 ${
                      step <= checkoutStep ? 'bg-green-600 text-white border-green-400 glow-green' : 'bg-gray-700 text-gray-400 border-gray-600'
                    }`}
                  >
                    {step}
                  </div>
                  {step < 3 && (
                    <div className={`w-16 h-1 mx-2 ${step < checkoutStep ? 'bg-green-600' : 'bg-gray-700'}`} />
                  )}
                </div>
              ))}
            </div>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            {/* Main Content */}
            <div className="lg:col-span-2">
              {checkoutStep === 1 && (
                <div className="bg-gray-900/50 p-6 rounded-lg border-2 border-green-500/30">
                  <h2 className="text-2xl font-bold text-green-400 mb-6 glow-green">{t('cart')}</h2>
                  {cart.length === 0 ? (
                    <p className="text-gray-400">VOTRE PANIER EST VIDE</p>
                  ) : (
                    <div className="space-y-4">
                      {cart.map((item) => (
                        <div key={`${item.id}-${item.selectedVariant?.id}`} className="flex items-center gap-4 bg-gray-800/50 p-4 rounded-lg border border-gray-700">
                          {item.image ? (
                            <img src={item.image || "/placeholder.svg"} alt={item.name[language]} className="w-16 h-16 object-cover rounded border-2 border-gray-600" />
                          ) : (
                            <SkullIcon className="w-16 h-16" />
                          )}
                          <div className="flex-1">
                            <h3 className="font-bold text-yellow-400 glow-yellow">{item.name[language]}</h3>
                            {item.selectedVariant && (
                              <p className="text-sm text-gray-400">{item.selectedVariant.name[language]}</p>
                            )}
                            <p className="text-green-400 font-bold glow-green">{item.price.toFixed(2)} CHF</p>
                          </div>
                          <div className="flex items-center gap-2">
                            {/* CORRECTED BUTTON COLORS: Green background becomes black, white text becomes green */}
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => updateQuantity(item.id, item.selectedVariant?.id, -1)}
                              className="w-8 h-8 p-0 bg-black border-2 border-green-400 text-green-400 hover:bg-green-400 hover:text-black"
                            >
                              <Minus className="w-3 h-3" />
                            </Button>
                            <span className="w-8 text-center text-green-400 font-bold glow-green">{item.quantity}</span>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => updateQuantity(item.id, item.selectedVariant?.id, 1)}
                              className="w-8 h-8 p-0 bg-black border-2 border-green-400 text-green-400 hover:bg-green-400 hover:text-black"
                            >
                              <Plus className="w-3 h-3" />
                            </Button>
                          </div>
                          {/* CORRECTED BUTTON COLORS: Red background becomes black, white text becomes red */}
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => {
                              if (item.quantity > 1) {
                                updateQuantity(item.id, item.selectedVariant?.id, -1)
                              } else {
                                removeFromCart(item.id, item.selectedVariant?.id)
                              }
                            }}
                            className="bg-black text-red-400 border-2 border-red-400 hover:bg-red-400 hover:text-black glow-red"
                          >
                            SUPPRIMER
                          </Button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {checkoutStep === 2 && (
                <div className="bg-gray-900/50 p-6 rounded-lg border-2 border-green-500/30">
                  <h2 className="text-2xl font-bold text-green-400 mb-6 glow-green">{t('deliveryInfo')}</h2>
                  
                  <div className="mb-6 p-4 bg-yellow-600/20 rounded-lg border-2 border-yellow-600">
                    <p className="text-yellow-400 text-sm font-bold glow-yellow">
                      ⚠️ {t('switzerlandOnly')}
                    </p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium mb-2">{t('firstName')} *</label>
                      <input
                        type="text"
                        value={checkoutForm.firstName}
                        onChange={(e) => {
                          e.preventDefault()
                          setCheckoutForm(prev => ({ ...prev, firstName: e.target.value }))
                        }}
                        className="w-full p-3 bg-gray-800 border-2 border-gray-600 rounded-lg focus:border-green-400 focus:outline-none text-white transition-all duration-200"
                        required
                        autoComplete="given-name"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">{t('lastName')} *</label>
                      <input
                        type="text"
                        value={checkoutForm.lastName}
                        onChange={(e) => {
                          e.preventDefault()
                          setCheckoutForm(prev => ({ ...prev, lastName: e.target.value }))
                        }}
                        className="w-full p-3 bg-gray-800 border-2 border-gray-600 rounded-lg focus:border-green-400 focus:outline-none text-white transition-all duration-200"
                        required
                        autoComplete="family-name"
                      />
                    </div>
                    <div className="md:col-span-2">
                      <label className="block text-sm font-medium mb-2">{t('email')} *</label>
                      <input
                        type="email"
                        value={checkoutForm.email}
                        onChange={(e) => {
                          e.preventDefault()
                          setCheckoutForm(prev => ({ ...prev, email: e.target.value }))
                        }}
                        className="w-full p-3 bg-gray-800 border-2 border-gray-600 rounded-lg focus:border-green-400 focus:outline-none text-white transition-all duration-200"
                        required
                        autoComplete="email"
                      />
                    </div>
                    <div className="md:col-span-2">
                      <label className="block text-sm font-medium mb-2">{t('address')} *</label>
                      <input
                        type="text"
                        value={checkoutForm.address}
                        onChange={(e) => {
                          e.preventDefault()
                          setCheckoutForm(prev => ({ ...prev, address: e.target.value }))
                        }}
                        className="w-full p-3 bg-gray-800 border-2 border-gray-600 rounded-lg focus:border-green-400 focus:outline-none text-white transition-all duration-200"
                        required
                        autoComplete="street-address"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">{t('city')} *</label>
                      <input
                        type="text"
                        value={checkoutForm.city}
                        onChange={(e) => {
                          e.preventDefault()
                          setCheckoutForm(prev => ({ ...prev, city: e.target.value }))
                        }}
                        className="w-full p-3 bg-gray-800 border-2 border-gray-600 rounded-lg focus:border-green-400 focus:outline-none text-white transition-all duration-200"
                        required
                        autoComplete="address-level2"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">{t('postalCode')} *</label>
                      <input
                        type="text"
                        value={checkoutForm.postalCode}
                        onChange={(e) => {
                          e.preventDefault()
                          setCheckoutForm(prev => ({ ...prev, postalCode: e.target.value }))
                        }}
                        className="w-full p-3 bg-gray-800 border-2 border-gray-600 rounded-lg focus:border-green-400 focus:outline-none text-white transition-all duration-200"
                        required
                        autoComplete="postal-code"
                      />
                    </div>
                    <div className="md:col-span-2">
                      <label className="block text-sm font-medium mb-2">{t('country')} *</label>
                      <select
                        value={checkoutForm.country}
                        onChange={(e) => {
                          e.preventDefault()
                          setCheckoutForm(prev => ({ ...prev, country: e.target.value }))
                        }}
                        className="w-full p-3 bg-gray-800 border-2 border-gray-600 rounded-lg focus:border-green-400 focus:outline-none text-white transition-all duration-200"
                        required
                      >
                        <option value="CH">{t('switzerland')}</option>
                      </select>
                    </div>
                  </div>

                  <div className="mt-6">
                    <h3 className="text-lg font-bold text-green-400 mb-4 glow-green">MODE DE LIVRAISON</h3>
                    <div className="space-y-3">
                      <label className="flex items-center p-4 border-2 border-gray-600 rounded-lg cursor-pointer hover:border-green-400 transition-colors">
                        <input
                          type="radio"
                          name="shipping"
                          value="standard"
                          checked={checkoutForm.shippingMethod === 'standard'}
                          onChange={(e) => {
                            e.preventDefault()
                            setCheckoutForm(prev => ({ ...prev, shippingMethod: e.target.value }))
                          }}
                          className="mr-3"
                        />
                        <div className="flex-1">
                          <div className="font-bold">{t('standardShipping')}</div>
                          <div className="text-sm text-gray-400">2-3 JOURS OUVRÉS</div>
                          <div className="text-green-400 font-bold glow-green">
                            {getTotalPrice() >= 50 ? 'GRATUIT' : '5.90 CHF'}
                          </div>
                        </div>
                      </label>
                      <label className="flex items-center p-4 border-2 border-gray-600 rounded-lg cursor-pointer hover:border-green-400 transition-colors">
                        <input
                          type="radio"
                          name="shipping"
                          value="express"
                          checked={checkoutForm.shippingMethod === 'express'}
                          onChange={(e) => {
                            e.preventDefault()
                            setCheckoutForm(prev => ({ ...prev, shippingMethod:
                            setCheckoutForm(prev => ({ ...prev, shippingMethod: e.target.value }))
                          }}
                          className="mr-3"
                        />
                        <div className="flex-1">
                          <div className="font-bold">{t('expressShipping')}</div>
                          <div className="text-sm text-gray-400">24-48H</div>
                          <div className="text-green-400 font-bold glow-green">12.90 CHF</div>
                        </div>
                      </label>
                    </div>
                  </div>
                </div>
              )}

              {checkoutStep === 3 && (
                <div className="bg-gray-900/50 p-6 rounded-lg border-2 border-green-500/30">
                  <h2 className="text-2xl font-bold text-green-400 mb-6 glow-green">{t('payment')}</h2>
                  
                  <div className="space-y-4">
                    <label className="flex items-center p-4 border-2 border-gray-600 rounded-lg cursor-pointer hover:border-green-400 transition-colors">
                      <input
                        type="radio"
                        name="payment"
                        value="card"
                        checked={checkoutForm.paymentMethod === 'card'}
                        onChange={(e) => {
                          e.preventDefault()
                          setCheckoutForm(prev => ({ ...prev, paymentMethod: e.target.value }))
                        }}
                        className="mr-3"
                      />
                      <div>
                        <div className="font-bold">{t('bankCard')}</div>
                        <div className="text-sm text-gray-400">VISA, MASTERCARD</div>
                      </div>
                    </label>
                    
                    <label className="flex items-center p-4 border-2 border-gray-600 rounded-lg cursor-pointer hover:border-green-400 transition-colors">
                      <input
                        type="radio"
                        name="payment"
                        value="twint"
                        checked={checkoutForm.paymentMethod === 'twint'}
                        onChange={(e) => {
                          e.preventDefault()
                          setCheckoutForm(prev => ({ ...prev, paymentMethod: e.target.value }))
                        }}
                        className="mr-3"
                      />
                      <div>
                        <div className="font-bold">{t('twint')}</div>
                        <div className="text-sm text-gray-400">PAIEMENT MOBILE SUISSE</div>
                      </div>
                    </label>
                    
                    <label className="flex items-center p-4 border-2 border-gray-600 rounded-lg cursor-pointer hover:border-green-400 transition-colors">
                      <input
                        type="radio"
                        name="payment"
                        value="paypal"
                        checked={checkoutForm.paymentMethod === 'paypal'}
                        onChange={(e) => {
                          e.preventDefault()
                          setCheckoutForm(prev => ({ ...prev, paymentMethod: e.target.value }))
                        }}
                        className="mr-3"
                      />
                      <div>
                        <div className="font-bold">{t('paypal')}</div>
                        <div className="text-sm text-gray-400">PAIEMENT SÉCURISÉ</div>
                      </div>
                    </label>
                  </div>

                  {checkoutForm.paymentMethod === 'twint' && (
                    <div className="mt-6 text-center">
                      <div className="bg-white p-4 rounded-lg inline-block border-2 border-gray-600">
                        <div className="w-48 h-48 bg-gray-200 flex items-center justify-center text-black text-sm font-bold">
                          QR CODE TWINT
                          <br />
                          {finalTotal.toFixed(2)} CHF
                        </div>
                      </div>
                      <p className="text-sm text-gray-400 mt-2">SCANNEZ AVEC VOTRE APP TWINT</p>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Order Summary */}
            <div className="bg-gray-900/50 p-6 rounded-lg h-fit border-2 border-green-500/30">
              <h3 className="text-xl font-bold text-green-400 mb-4 glow-green">RÉSUMÉ DE COMMANDE</h3>
              
              <div className="space-y-3 mb-4">
                {cart.map((item) => (
                  <div key={`${item.id}-${item.selectedVariant?.id}`} className="flex justify-between text-sm">
                    <span>
                      {item.name[language]} {item.selectedVariant && `(${item.selectedVariant.name[language]})`} x{item.quantity}
                    </span>
                    <span className="text-yellow-400 glow-yellow">{(item.price * item.quantity).toFixed(2)} CHF</span>
                  </div>
                ))}
              </div>

              <div className="border-t border-gray-700 pt-4 space-y-2">
                <div className="flex justify-between">
                  <span>{t('subtotal')}</span>
                  <span>{getTotalPrice().toFixed(2)} CHF</span>
                </div>
                <div className="flex justify-between">
                  <span>{t('shipping')}</span>
                  <span>{shippingCost.toFixed(2)} CHF</span>
                </div>
                <div className="flex justify-between">
                  <span>{t('vat')} (7.7%)</span>
                  <span>{vatAmount.toFixed(2)} CHF</span>
                </div>
                <div className="border-t border-gray-700 pt-2">
                  <div className="flex justify-between text-xl font-bold">
                    <span>{t('total')}</span>
                    <span className="text-green-400 glow-green">{finalTotal.toFixed(2)} CHF</span>
                  </div>
                </div>
              </div>

              {getTotalPrice() >= 50 && (
                <div className="mt-4 p-3 bg-green-600/20 rounded-lg border border-green-500">
                  <p className="text-green-400 text-sm glow-green">
                    🎉 {t('freeShipping')}
                  </p>
                </div>
              )}

              <div className="mt-6 space-y-4">
                {checkoutStep > 1 && (
                  <Button
                    onClick={() => setCheckoutStep(checkoutStep - 1)}
                    className="w-full bg-gray-700 hover:bg-gray-600 text-white border-2 border-gray-600 font-bold transition-all duration-300"
                  >
                    {t('back')}
                  </Button>
                )}
                
                {checkoutStep < 3 ? (
                  <Button
                    onClick={() => {
                      if (checkoutStep === 2 && !isFormValid) {
                        alert('VEUILLEZ REMPLIR TOUS LES CHAMPS OBLIGATOIRES')
                        return
                      }
                      setCheckoutStep(checkoutStep + 1)
                    }}
                    disabled={cart.length === 0}
                    className="w-full bg-green-600 hover:bg-green-700 text-white border-2 border-green-400 font-bold transition-all duration-300"
                  >
                    {t('continue')}
                  </Button>
                ) : (
                  <Button
                    onClick={() => {
                      // Simulate payment processing
                      const success = Math.random() > 0.1 // 90% success rate
                      if (success) {
                        changePage('success')
                        clearCart()
                        setCheckoutStep(1)
                      } else {
                        changePage('error')
                      }
                    }}
                    className="w-full bg-green-600 hover:bg-green-700 text-white border-2 border-green-400 font-bold transition-all duration-300"
                  >
                    {t('confirm')}
                  </Button>
                )}
              </div>

              <div className="mt-4 text-center">
                <p className="text-xs text-gray-400">
                  🔒 PAIEMENT 100% SÉCURISÉ SSL
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }

  const SuccessPage = () => (
    <div className="min-h-screen bg-black text-white flex items-center justify-center p-4">
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{ 
          backgroundImage: "url('/fond-shop.png')"
        }}
      />
      <div className="bg-gray-900 p-8 rounded-lg w-full max-w-md text-center border-2 border-green-500/30 relative z-10">
        <div className="text-6xl mb-6">✅</div>
        <h2 className="text-3xl font-bold text-green-400 mb-4 glow-green">{t('orderConfirmed')}</h2>
        <p className="text-gray-300 mb-8">{t('thankYou')}</p>
        
        <div className="bg-gray-800 p-4 rounded-lg mb-6 border border-gray-700">
          <h3 className="text-lg font-bold mb-2">RÉCAPITULATIF DE COMMANDE</h3>
          <p className="text-sm text-gray-400">COMMANDE #MW{Date.now().toString().slice(-6)}</p>
          <p className="text-sm text-gray-400">UN EMAIL DE CONFIRMATION VOUS A ÉTÉ ENVOYÉ</p>
        </div>

        <div className="space-y-3">
          <Button
            onClick={() => changePage('shop')}
            className="w-full bg-green-600 hover:bg-green-700 text-white border-2 border-green-400 font-bold transition-all duration-300"
          >
            CONTINUER MES ACHATS
          </Button>
          
          <Button
            onClick={() => {
              window.location.href = 'mailto:Bilal.ghanmi1@gmail.com?subject=Erreur de destination - Commande MyWeed\'s&body=Bonjour, j\'ai un problème avec ma commande.'
              changePage('faq')
            }}
            className="w-full bg-transparent border-2 border-cyan-400 text-cyan-400 hover:bg-cyan-400 hover:text-black"
          >
            CONTACTER LE SUPPORT
          </Button>
        </div>
      </div>
    </div>
  )

  const ErrorPage = () => (
    <div className="min-h-screen bg-black text-white flex items-center justify-center p-4">
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{ 
          backgroundImage: "url('/fond-shop.png')"
        }}
      />
      <div className="bg-gray-900 p-8 rounded-lg w-full max-w-md text-center border-2 border-red-500/30 relative z-10">
        <div className="text-6xl mb-6">💀</div>
        <h2 className="text-3xl font-bold text-red-400 mb-4 glow-red">{t('errorTitle')}</h2>
        <p className="text-gray-300 mb-8">{t('errorMessage')}</p>
        
        <Button
          onClick={() => changePage('checkout')}
          className="w-full bg-red-600 hover:bg-red-700 text-white border-2 border-red-400 font-bold transition-all duration-300"
        >
          RÉESSAYER LE PAIEMENT
        </Button>
      </div>
    </div>
  )

  return (
    <>
      {currentPage === 'home' && <HomePage />}
      {currentPage === 'shop' && <ShopPage />}
      {currentPage === 'login' && <LoginPage />}
      {currentPage === 'register' && <RegisterPage />}
      {currentPage === 'forgot-password' && <ForgotPasswordPage />}
      {currentPage === 'reset-password' && <ResetPasswordPage />}
      {currentPage === 'faq' && <FAQPage />}
      {currentPage === 'checkout' && <CheckoutPage />}
      {currentPage === 'success' && <SuccessPage />}
      {currentPage === 'error' && <ErrorPage />}
      {isTransitioning && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 transition-all duration-400" />
      )}
    </>
  )
}
